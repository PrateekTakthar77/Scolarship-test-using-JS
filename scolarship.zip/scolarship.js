let marksENG = 89
let marksPHY = 80
let marksCHEM = 85
let marksMATHS = 50
let marksBIO = 98

let totalMarks = marksENG + marksPHY + marksCHEM + marksMATHS + marksBIO 

if (totalMarks >= 400){
    console.log("you are selected for the scolarship")
}else
    console.log("you not are selected for the scolarship")
